package com.company;

public class Main {

    public static void main(String[] args) {
        String nodb;
        int num = 2;
        String word = "lol";
        num += 8;
        if (num < 0) {
            System.out.println("Вы сохранили отрицательное число");
        }else if (num > 0) {
            System.out.println("Вы сохранили положительное число");
        }else {
            System.out.println("Вы сохранили нуль");
        }
    }
}